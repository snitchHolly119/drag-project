//let log = console.log;

let basket1 = document.getElementById("basket1");
let basket2 = document.getElementById("basket2");
let basket3 = document.getElementById("basket3");
//log(basket3);

let itemsCode = "";

for (let index = 0; index < 5; index++) {
  itemsCode =
    itemsCode +
    `<span class = 'game-item' data-type = 'ribbon'  draggable = 'true' id = 'item-${index}'></span>`;
  itemsCode =
    itemsCode +
    `<span class = 'game-item bauble' data-type = 'bauble' id = 'item-${index + 3 * 2}' draggable = 'true'></span>`;
}

basket2.innerHTML = itemsCode;

let items = document.getElementsByClassName("game-item");
//log(items)
function dragSart(event) {
  event.dataTransfer.setData("text", event.target.id);
}

function dragOver(event) {
  event.preventDefault();
}

function drop(event) {
  event.preventDefault();
  const data = event.dataTransfer.getData("text");
  console.log(data);
  console.log(document.getElementById(data));
  event.target.appendChild(document.getElementById(data));
}

//let test = items

for (let index = 0; index < items.length; index++) {
  //log(items[index]);
  items[index].addEventListener("dragstart", function (event) {
    dragSart(event);
  });
}

basket3.addEventListener("dragover", function (event) {
  dragOver(event);
});

basket3.addEventListener("drop", function (event) {
  drop(event);
  if (event.target.lastChild.dataset.type != "bauble") {
    //event.target.classList.add("grey");
    event.target.lastChild.classList.add("grey");
  } else {
    event.target.lastChild.classList.remove("grey");
  }
});

basket1.addEventListener("dragover", function (event) {
  dragOver(event);
  //if (event.target.lastChild.dataset.type != "bauble") {
  //element.classList.remove("grey");
  //};
});

basket1.addEventListener("drop", function (event) {
  drop(event);
  if (event.target.lastChild.dataset.type != "ribbon") {
    //event.target.classList.add("grey");
    event.target.lastChild.classList.add("grey");
  } else {
    event.target.lastChild.classList.remove("grey");
  }
});

basket2.addEventListener("dragover", function (event) {
  dragOver(event);
});

basket2.addEventListener("drop", function (event) {
  drop(event);
  event.target.lastChild.classList.remove("grey");
});

//if(items[0].src.includes("bauble")){items[0].class = "grey"};
//log(items[0].dataset.type);
//log(items[2].dataset.type);

let btn = document.getElementById("start");
//click event not onclick
btn.addEventListener("click", function () {
  let startScreen = document.getElementById("start-screen");
  startScreen.style.display = "none"; // removes the start screen
});
